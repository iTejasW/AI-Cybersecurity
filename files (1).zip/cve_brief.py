import requests
import json
import os
from anthropic import Anthropic
from dotenv import load_dotenv

# Load API key from .env file
load_dotenv()
client = Anthropic()


# ── Fetch CVE Data from NVD API ───────────────────────────────────────────────

def get_cve_data(cve_id):
    url = f"https://services.nvd.nist.gov/rest/json/cves/2.0?cveId={cve_id}"

    try:
        response = requests.get(url, timeout=10)
        data = response.json()
    except Exception as e:
        print(f"[-] API request failed: {e}")
        return None

    if not data.get("vulnerabilities"):
        return None  # CVE not found

    vuln = data["vulnerabilities"][0]["cve"]
    description = vuln["descriptions"][0]["value"]
    published = vuln["published"]

    # Handle both CVSS v3.1 and v2
    metrics = vuln.get("metrics", {})
    if "cvssMetricV31" in metrics:
        cvss_data = metrics["cvssMetricV31"][0]["cvssData"]
    elif "cvssMetricV2" in metrics:
        cvss_data = metrics["cvssMetricV2"][0]["cvssData"]
    else:
        cvss_data = {"baseScore": "N/A", "baseSeverity": "UNKNOWN"}

    return {
        "cve_id": cve_id,
        "description": description,
        "cvss_score": cvss_data["baseScore"],
        "severity": cvss_data.get("baseSeverity", "UNKNOWN"),
        "published": published
    }


# ── Generate Threat Brief via Claude API ─────────────────────────────────────

def generate_threat_brief(cve_data):
    prompt = f"""
You are a senior cybersecurity analyst writing a threat brief for a SOC team.
Based on the CVE data below, write a concise, actionable threat brief.

CVE ID      : {cve_data['cve_id']}
Severity    : {cve_data['severity']} ({cve_data['cvss_score']})
Published   : {cve_data['published']}
Description : {cve_data['description']}

Structure your response EXACTLY like this with no extra commentary:

SUMMARY
2-3 sentences explaining what the vulnerability is in plain English.

AFFECTED SYSTEMS
What specific products and versions are affected.

RECOMMENDED ACTION
Specific steps the SOC team should take right now, in order of priority.

THREAT LEVEL ASSESSMENT
Is this being actively exploited in the wild? How urgent is remediation?
"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        messages=[{"role": "user", "content": prompt}]
    )

    return message.content[0].text


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    print("\n========================================")
    print("      CVE THREAT BRIEF GENERATOR")
    print("========================================")

    cve_id = input("\nEnter CVE ID (e.g. CVE-2021-44228): ").strip().upper()

    print(f"\n[+] Fetching CVE data for {cve_id}...")
    cve_data = get_cve_data(cve_id)

    if not cve_data:
        print("[-] CVE not found. Check the ID and try again.")
        return

    print(f"[+] Severity : {cve_data['severity']} ({cve_data['cvss_score']})")
    print(f"[+] Published: {cve_data['published']}")
    print(f"[+] Generating AI threat brief...\n")

    brief = generate_threat_brief(cve_data)

    output = f"""
========================================
   CVE THREAT BRIEF
========================================
CVE ID   : {cve_data['cve_id']}
Severity : {cve_data['severity']} ({cve_data['cvss_score']})
Published: {cve_data['published']}
----------------------------------------

{brief}

========================================
"""

    print(output)

    # Save to file
    filename = f"{cve_id}_threat_brief.txt"
    with open(filename, "w") as f:
        f.write(output)
    print(f"[+] Brief saved to: {filename}")


if __name__ == "__main__":
    main()
